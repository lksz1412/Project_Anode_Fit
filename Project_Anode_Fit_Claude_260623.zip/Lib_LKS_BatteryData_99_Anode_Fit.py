# -*- coding: utf-8 -*-
# ==============================================================================
# graphite_anode_dqdv  (v1.0.2)
# 흑연 음극(Graphite anode) 방전 ICA 곡선 dQ/dV 의 "평활(미분 가능)" 물리 근사 모델
# ==============================================================================
# [무엇을 하는 코드인가]
#   흑연 음극의 상전이(stage transition) 하나하나를 dQ/dV "peak" 로 근사하고,
#   그 peak 들을 합산(중첩)하여 음극 Coin Half Cell(CHC) 의 dQ/dV 곡선 개형을
#   "전 구간 미분가능한 매끈한 곡선" 으로 산출한다. (피팅에 바로 쓸 모델식.)
#
# [왜 평활(매끈)해야 하나]
#   실측 dQ/dV 는 매끈한 누적용량 Q(V) 의 도함수이므로 본질적으로 매끈하다.
#   따라서 모델도 미분가능해야 실데이터에 매칭(피팅)된다.
#
# [물리 근거 – 문건 graphite_ica_ch1_Opus_v4.tex 의 "일반해(평활 원형)"]
#   지연(lag) r_j 는 1계 선형 ODE 식(1.54) eq:Lq : dr/dq + r/L_q = dξ_eq/dq 를 만족하며,
#   그 닫힌 일반해(식(1.57) eq:memory)는 "지수 기억 커널과의 합성곱(식(1.58) eq:conv)":
#       r_j(q) = ∫ exp(-(q-q')/L_q) · (dξ_eq/dq') dq'      ← 합성곱 이라 매끈
#   관측식(식(1.76) eq:closed):
#       dQ/dV_n = C_bg + Σ_j Q_j · d/dV_n ( ξ_eq,j - r_j ) = C_bg + Σ_j Q_j · dξ_j/dV_n
#   본 코드는 위 식을 "전압축 등가형(국소 L_V = |dV_n/dq|·L_q)" 으로 구현한다:
#       dξ_j/dV_n = (ξ_eq - ξ_j) / L_V        (1계 완화 ODE)
#       → ξ_j(V_n) = ξ_eq 를 길이 L_V 의 인과 지수필터로 저역통과 시킨 것(= 합성곱, 매끈)
#       → dQ/dV = C_bg + Σ_j Q_j · (ξ_eq,j - ξ_j) / L_V_j
#
# [검증된 성질]
#   - 전 구간 미분가능(C1 연속): 지수필터(합성곱)는 불연속을 만들지 않는다.
#   - |I|→0 극한: L_V → 0 → ξ_j → ξ_eq → dQ/dV → 평형 종(식(1.51) eq:eqpeak) 회수.
#   - 면적 보존: ∫dξ_j = ∫dξ_eq = 1 (합성곱은 면적 보존) → 각 peak 면적 = Q_j.
#
# [v4.tex 식 번호 ↔ 코드 대응]  (각 함수가 기반한 문건 식 번호; .aux 컴파일 기준)
#   equilibrium_occupation   ξ_eq       ← 식(1.27) eq:logistic
#   hysteresis_gap           ΔU_hys     ← 식(1.88) eq:hysdU
#   branch_center            U^d        ← 식(1.91) eq:hyscenter
#   ln_memory_length         ln L_q     ← 식(1.69) eq:lnLq   (T* = 식(1.68) eq:LqT)
#   _causal_lowpass          지연 ξ_j   ← 식(1.54) eq:Lq → 식(1.57)/(1.58) eq:memory/eq:conv
#   .equilibrium()           |I|→0 종   ← 식(1.51) eq:eqpeak, (1.50) eq:dxidV
#   .dqdv()                  dQ/dV      ← 식(1.76) eq:closed; V_n 환산 = 식(1.45) eq:vapp
#
# [범위] 방전(discharge, 방향부호 σ_d = +1) 전용. 충전·히스테리시스
# ==============================================================================
#
# ==============================================================================
# [계산 흐름도 — graphite_anode_dqdv 파이프라인]
# ------------------------------------------------------------------------------
#   각 단계 우측의 (1.xx) 는 물리 근거 문건(graphite_ica_ch1 …)의 식 번호.
#   메인 경로 = dqdv(유한율 방전),  별도 경로 = equilibrium(|I|→0 평형 기준선).
#
#   [입력 — 실험 기반 시작값]
#     전이 j 마다 : U_j 중심전위 · w_j 폭 · Q_j 면적(용량)
#       동역학 옵션 : Ω_j 상호작용 · γ_j 분기축소 · ΔH_a,j^eff 유효활성엔탈피
#                     · b_j prefactor보정 · |dV_n/dq|_qa 컷 OCV기울기 · h_η 부분cycle
#       (시작점 U_j 는 ΔG=−sFU·∂U/∂T=ΔS/sF 로 H_j·S_j 에, b_j·ΔH^eff 는 H_a,j·S_a,j 에 연결)
#     전역 : χ 전하전달계수 · R_n 분극저항 · C_bg 배경
#     호출 : V_app 측정전위격자 · T 온도 · |I| 전류 · Q_cell 셀용량
#         │
#         ▼
#   [A] 분극 환산   V_n = V_app − σ_d·|I|·R_n   (σ_d=+1)            ← (1.45) eq:vapp
#         │
#         ▼
#   [B] 균일 작업격자 V_work 생성 (저전위쪽 패딩 = 꼬리 기억 확보)
#         │
#         ▼
#   [C] 배경 초기화   dQ/dV ← C_bg(V_work)                          ← (1.43) eq:cbg
#         │
#         ▼
#   ┌─ 전이 j 루프 (peak 하나씩) ──────────────────────────────────────────┐
#   │ [D] 분기중심 U^d                                                       │
#   │       Ω/γ 있으면 : U^d = U + σ_d·½·h_η·γ·ΔU_hys(T,Ω)         ← (1.91) eq:hyscenter
#   │         ΔU_hys = (2/F)[Ω·u − 2RT·artanh(u)], u=√(1−2RT/Ω)   ← (1.88) eq:hysdU
#   │         Ω≤2RT(상분리 없음) → ΔU_hys=0 → U^d=U   (u: spinodal (1.40))   │
#   │ [E] 평형 점유   ξ_eq = 1/(1+exp(−(V_work−U^d)/w))            ← (1.27) eq:logistic
#   │ [F] 지연 길이 L_V                                                      │
#   │       직접 'L_V' 지정,  또는 동역학 :                                  │
#   │         L_V = |dV_n/dq|·L_q,   L_q = exp(ln L_q)             ← (1.69) eq:lnLq
#   │         ln L_q = ln(T*/T)+ΔH_a^eff/RT+b−χA/RT, T*=|I|h/(Q_cell k_B)  ← (1.68) eq:LqT
#   │         A = 전이당 대표 affinity(동역학 분기는 _resolve_lag_length 의 4RT 상수)│
#   │         (전이대 A<3RT 보정 −ln(1+e^−A/RT) [M3]: 직접 affinity 입력 시만 발동;     │
#   │          4RT 경로(A=4RT>3RT)에선 미발동 — dead branch)                  │
#   │ [G] peak 형상 dξ_j/dV                                                  │
#   │       L_V<2ΔV(저율·|I|→0) : ξ_eq(1−ξ_eq)/w          ← (1.50) eq:dxidV/(1.51) eqpeak
#   │       아니면 : ξ_j = 인과 지수 저역통과(ξ_eq, ΔV, L_V)  ← (1.54)eq:Lq→(1.57/1.58)memory/conv
#   │               dξ_j/dV = (ξ_eq − ξ_j)/L_V   (합성곱 → 매끈)   ← (1.76) eq:closed
#   │ [H] 누적   dQ/dV += Q_j · dξ_j/dV                            ← (1.82) eq:total
#   └──────────────────────────────────────────────────────────────────────┘
#         │
#         ▼
#   [I] 작업격자 → 입력격자 보간 → dQ/dV 출력
#
#   [별도 경로] equilibrium(V_n) — |I|→0 평형 기준선 (저율 OCV·S1 피팅용)
#     dQ/dV = C_bg + Σ_j Q_j·ξ_eq(1−ξ_eq)/w_j   (지연·꼬리 없음)   ← (1.51) eq:eqpeak
# ==============================================================================

from __future__ import annotations
import numpy as np
from typing import Dict, Any, List, Union, Callable

# ------------------------------------------------------------------------------
# 물리 상수 (SI 단위)
# ------------------------------------------------------------------------------
GAS_CONSTANT_R  = 8.314           # R   : 기체 상수      [J/(mol·K)]
FARADAY_F       = 96485.0         # F   : 패러데이 상수  [C/mol]
BOLTZMANN_KB    = 1.380649e-23    # k_B : 볼츠만 상수    [J/K]
PLANCK_H        = 6.62607015e-34  # h   : 플랑크 상수    [J·s]

# 입력/출력이 스칼라(float)일 수도, 배열(np.ndarray)일 수도 있음을 나타내는 타입 별칭
ScalarOrArray = Union[float, np.ndarray]


# ==============================================================================
# 물리 헬퍼 함수들  (각 함수 = 문건의 한 식)
# ==============================================================================
def equilibrium_occupation(V_internal: ScalarOrArray,
                           center_potential: float,
                           width: float) -> ScalarOrArray:
    """평형 점유율 ξ_eq  (로지스틱 형태).  [_v4.tex 식 (1.27) eq:logistic]

    한 상전이가 "평형(무한히 느린 속도)"에서 가지는 점유율(0~1):
        ξ_eq(V_n) = 1 / ( 1 + exp( -(V_n - U) / w ) )

    매개변수
        V_internal       : 내부(음극) 전위 V_n   [V]  (스칼라 또는 배열)
        center_potential : 전이 중심 전위 U (또는 분기중심 U^d)  [V]
        width            : 전이 폭 w (≈ RT/F ≈ 25.7 mV @25°C)  [V]

    반환: ξ_eq  (0~1, 무차원).  방전 규약상 부호 s=+1 이므로 식에 부호 생략.
    """
    # 정규화 거리 z = (V_n - U) / w  (전이 중심에서 폭 단위로 얼마나 떨어졌나)
    z = (np.asarray(V_internal, dtype=float) - center_potential) / width
    # exp 오버플로 방지를 위한 수치 안정형 로지스틱 (z 부호에 따라 분기; 값은 동일)
    return np.where(z >= 0,
                    1.0 / (1.0 + np.exp(-z)),          # z>=0 : 표준형
                    np.exp(z) / (1.0 + np.exp(z)))     # z<0  : 등가형(언더플로 안전)


def hysteresis_gap(temperature: float, interaction: float) -> float:
    """상분리 히스테리시스 gap  ΔU_hys [V].  [_v4.tex 식 (1.88) eq:hysdU]

    상호작용 Ω 가 2RT 를 넘으면(상분리 발생) 충/방전 평형 전위가 갈라지는 폭:
        ΔU_hys = (2/F) · [ Ω·u - 2RT·artanh(u) ],   u = sqrt(1 - 2RT/Ω)
    Ω <= 2RT (상분리 없음) 이면 0.

    매개변수
        temperature : 절대온도 T   [K]
        interaction : 상호작용 에너지 Ω   [J/mol]

    반환: ΔU_hys [V] (>=0).
    """
    two_RT = 2.0 * GAS_CONSTANT_R * temperature   # 2RT : 상분리 임계 상호작용
    if interaction <= two_RT:                     # Ω <= 2RT → 상분리 없음
        return 0.0
    u = np.sqrt(1.0 - two_RT / interaction)
    return (2.0 / FARADAY_F) * (interaction * u - two_RT * np.arctanh(u))


def branch_center(temperature: float,
                  base_center: float,
                  interaction: float,
                  branch_fraction: float,
                  direction_sign: int = +1,
                  partial_cycle: float = 1.0) -> float:
    """방향별 분기중심 전위 U^d [V].  [_v4.tex 식 (1.91) eq:hyscenter]

    상분리가 있으면 방전 peak 중심이 기본중심 U 에서 gap 의 절반만큼 이동한다:
        U^d = U + σ_d · 0.5 · h_eta · γ · ΔU_hys(T, Ω)

    매개변수
        temperature     : 절대온도 T   [K]
        base_center     : 기본 전이 중심 U   [V]
        interaction     : 상호작용 Ω   [J/mol]
        branch_fraction : 실측 분기 축소인자 γ (0~1)
        direction_sign  : 방향부호 σ_d (방전 +1, 충전 -1)
        partial_cycle   : 부분 cycle 보정 h_eta (기본 1.0 = 완전 cycle)

    반환: U^d [V].  Ω<=2RT 이면 ΔU_hys=0 이므로 U^d = U.
    """
    return base_center + direction_sign * 0.5 * partial_cycle * \
        branch_fraction * hysteresis_gap(temperature, interaction)


def ln_memory_length(temperature: float,
                     current_abs: float,
                     cell_capacity: float,
                     activation_enthalpy_eff: float,
                     prefactor_term: float,
                     transfer_coeff: float,
                     affinity: float) -> float:
    """기억 길이 L_q 의 자연로그 ln(L_q) (무차원).  [_v4.tex 식 (1.69) eq:lnLq; T* = 식 (1.68) eq:LqT]

    ln L_q = ln(T*/T) + ΔH_a^eff/RT + b - χ·A/RT,   T* = |I|·h / (Q_cell·k_B)
    여기서 L_q 는 "용량축에서 계가 기억하는 최근 과거의 길이"(dQ 분해능에 해당).

    매개변수
        temperature             : 절대온도 T   [K]
        current_abs             : 전류 절댓값 |I|   [A]  (방전율)
        cell_capacity           : 셀 용량 Q_cell   [C]
        activation_enthalpy_eff : 유효 활성화 엔탈피 ΔH_a^eff   [J/mol]  (Ω 흡수된 값)
        prefactor_term          : prefactor 보정 b (= -S4 절편)  [무차원]
        transfer_coeff          : 전하전달계수 χ (0~1)
        affinity                : 구동력(affinity) A = sF(V-U)   [J/mol]  (꼬리에서 >=0)

    반환: ln(L_q).  |I|→0 이면 -inf (L_q→0, 평형 극한).
    주의: 전위 항에 χ 계수가 반드시 포함된다 (-χ·A/RT).
    """
    if current_abs <= 0:                          # |I|→0 : 기억 없음 → L_q→0 → 평형 극한
        return -np.inf
    # T*: 시도(attempt) 온도 스케일 = |I|·h / (Q_cell·k_B)   [K]
    attempt_temp = current_abs * PLANCK_H / (cell_capacity * BOLTZMANN_KB)
    ln_Lq = (np.log(attempt_temp / temperature)                          # 율(rate) 의존 항
             + activation_enthalpy_eff / (GAS_CONSTANT_R * temperature)  # 온도(Arrhenius) 항
             + prefactor_term                                            # prefactor/엔트로피 보정 b
             - transfer_coeff * affinity / (GAS_CONSTANT_R * temperature))  # 전위(χ·A) 항
    # 전이대(A < 3RT) 보정: 보편형 괄호인자로 L_q 를 나눔 → 로그에서 빼기 [문건 M3]
    if affinity < 3.0 * GAS_CONSTANT_R * temperature:
        ln_Lq -= np.log(1.0 + np.exp(-affinity / (GAS_CONSTANT_R * temperature)))
    return ln_Lq


def _causal_lowpass(source_signal: np.ndarray,
                    grid_step: float,
                    lag_length: float) -> np.ndarray:
    """인과(causal) 지수 저역통과 필터 — 지연 ξ_j 를 계산하는 수치 엔진.
    [_v4.tex 식 (1.54) eq:Lq → (1.57) eq:memory / (1.58) eq:conv]

    완화 ODE  dξ_j/dV = (ξ_eq - ξ_j)/L_V  의 닫힌 해(= 지수 기억 합성곱, eq:memory)를
    "균일 격자에서의 인과 지수 평활" 로 구현한다:
        a = exp(-ΔV / L_V)                       (한 격자당 감쇠율, 0~1)
        ξ_j[i] = a·ξ_j[i-1] + (1-a)·ξ_eq[i]       (과거를 a 만큼 기억)
    초기조건은 rest(ξ_j[0] = ξ_eq[0]).  이 필터는 본질적으로 매끈하다(불연속 없음).

    매개변수
        source_signal : 원천 신호 ξ_eq (균일 격자 위 배열)
        grid_step     : 격자 간격 ΔV   [V]
        lag_length    : 지연 길이 L_V   [V]

    반환: 지연된 점유율 ξ_j (source 와 같은 길이의 배열).
    """
    # 지연 길이가 0 이하/비유한이면 지연 없음 → ξ_j = ξ_eq (평형 추종)
    if lag_length <= 0 or not np.isfinite(lag_length):
        return source_signal.copy()
    decay_per_step = float(np.exp(-grid_step / lag_length))   # a = exp(-ΔV/L_V)
    try:
        # scipy 1극점 IIR 필터로 가속: y[i] = a·y[i-1] + (1-a)·x[i]
        from scipy.signal import lfilter
        initial_state = np.array([decay_per_step * source_signal[0]])  # ξ_j[0]=ξ_eq[0] 되도록
        lagged, _ = lfilter([1.0 - decay_per_step],          # 분자 계수 (1-a)
                            [1.0, -decay_per_step],           # 분모 계수 (1, -a)
                            source_signal, zi=initial_state)
        return lagged
    except Exception:
        # scipy 없을 때 numpy 폴백 (동일 점화식)
        lagged = np.empty_like(source_signal)
        lagged[0] = source_signal[0]
        for i in range(1, source_signal.size):
            lagged[i] = decay_per_step * lagged[i - 1] + (1.0 - decay_per_step) * source_signal[i]
        return lagged


# ==============================================================================
# 메인 클래스 — 평활 방전 dQ/dV 근사 모델
# ==============================================================================
class GraphiteAnodeDischargeDQDV:
    # [클래스 개요]
    # 흑연 음극의 여러 상전이(peak)를 받아, 방전 dQ/dV 곡선을 "매끈하게" 계산한다.
    #   dQ/dV_app = C_bg + Σ_j Q_j · (ξ_eq,j - ξ_j) / L_V_j   [eq:closed]
    #   ξ_eq : 평형 점유(로지스틱), ξ_j : 그것을 길이 L_V 로 지연시킨 것(매끈).
    # ----------------------------------------------------------------------
    # [파라미터 레퍼런스]  (생성 시 transitions 리스트의 각 dict 키)
    # 필수:
    #   'U'   : 전이 중심 전위  U_j   [V]   예) 0.085, 0.11, 0.14, 0.21
    #   'w'   : 전이 폭  w_j   [V]   예) 0.01~0.025 (≈RT/F)
    #   'Q'   : 전이 면적(용량)  Q_j   [Q_cell 단위]   (Σ Q_j ≈ 전체)
    #   지연 길이(둘 중 하나):
    #   'L_V' : 지연 길이  L_V_j   [V]   ← 직접 지정(가장 단순; 피팅용)
    #           (작을수록 평형에 가까운 또렷한 종 / 클수록 꼬리가 길고 완만)
    #   또는 아래 동역학 파라미터로 L_V 를 자동계산(L_V = |dVdq_qa|·L_q):
    #   'Omega'   : 상호작용  Ω_j   [J/mol]   (>2RT 면 상분리/분기)
    #   'gamma'   : 분기 축소인자  γ_j   (0~1)
    #   'dHa_eff' : 유효 활성화엔탈피  ΔH_a^eff   [J/mol]
    #   'b'       : prefactor 보정  b_j   [무차원]   (= -S4 절편)
    #   'dVdq_qa' : 컷에서의 OCV 기울기  |dV_n/dq|   [V/(Q_cell)]   (L_V=|dVdq|·L_q)
    #   선택:
    #   'h_eta'   : 부분 cycle 보정  h_eta   (기본 1.0)
    # ----------------------------------------------------------------------
    # [전역 파라미터]  (생성자 인자)
    #   chi  : 전하전달계수 χ (0~1)         — 동역학 L_V 계산에 사용
    #   Rn   : 분극 저항 R_n                — 내부전위 V_n = V_app - |I|·R_n
    #   Cbg  : 배경 dQ/dV C_bg              — 상수(float) 또는 함수 callable(V_n)
    # [호출 시 파라미터]  dqdv(V_app, T, I_abs, Q_cell)
    #   V_app  : 측정(겉보기) 전위 격자  [V]  (정렬되어 있으면 됨)
    #   T      : 절대온도  [K]
    #   I_abs  : 방전 전류 절댓값 |I|  [A]
    #   Q_cell : 셀 용량  [C]
    # ======================================================================

    def __init__(self,
                 transitions: List[Dict[str, Any]],
                 chi: float = 0.5,
                 Rn: float = 0.0,
                 Cbg: Union[float, Callable] = 0.0):
        """모델 생성.  transitions = 상전이(peak) dict 들의 리스트(위 레퍼런스 참조)."""
        # — 입력 검증 (잘못된 파라미터는 NaN 오염 전에 즉시 알림) —
        if not transitions:
            raise ValueError("transitions 리스트가 비어 있습니다(최소 1개 전이 필요).")
        for idx, tr in enumerate(transitions):
            if tr.get('w', 0) <= 0:                # 폭 w>0 (로지스틱 0除/NaN 방지)
                raise ValueError(f"transition[{idx}]: 폭 'w' 는 0보다 커야 합니다.")
            if tr.get('Q', -1) < 0:                # 면적 Q>=0
                raise ValueError(f"transition[{idx}]: 면적 'Q' 는 0 이상이어야 합니다.")
        self.transitions = transitions             # 상전이(peak) 목록
        self.transfer_coeff = chi                  # χ : 전하전달계수
        self.polarization_resistance = Rn          # R_n : 분극 저항
        self.background = Cbg                       # C_bg : 배경 dQ/dV

    # ----------------------------------------------------------------------
    def _resolve_lag_length(self,
                            transition: Dict[str, Any],
                            temperature: float,
                            current_abs: float,
                            cell_capacity: float) -> float:
        """전이 하나의 지연 길이 L_V [V] 를 결정.

        - dict 에 'L_V' 가 있으면 그대로 사용(실측 피팅용, 가장 단순).
        - 없으면 동역학 파라미터로 계산: L_V = |dV_n/dq| · L_q,  L_q=exp(ln_memory_length).
          (대표 affinity 는 전이대 밖 ~4RT 로 둠; 문건의 "상수-L_q 근사".)
        """
        if 'L_V' in transition and transition['L_V'] is not None:
            return float(transition['L_V'])               # 직접 지정된 지연 길이
        # 동역학 계산용 대표 affinity (전이대 밖 ~4RT, 보수적)
        representative_affinity = 4.0 * GAS_CONSTANT_R * temperature
        memory_length_q = np.exp(ln_memory_length(        # L_q (무차원, 용량축)
            temperature, current_abs, cell_capacity,
            transition['dHa_eff'], transition.get('b', 0.0),
            self.transfer_coeff, representative_affinity))
        # L_V = |dV_n/dq| · L_q  (용량축 길이를 전압축 길이로 환산)
        return abs(transition.get('dVdq_qa', 0.0)) * float(memory_length_q)

    # ----------------------------------------------------------------------
    def equilibrium(self, V_internal: ScalarOrArray) -> ScalarOrArray:
        """|I|→0 평형 극한의 dQ/dV (매끈한 종들의 합).
        [_v4.tex 식 (1.51) eq:eqpeak · (1.50) eq:dxidV; (1.94) eq:master 의 |I|→0 극한]

        dQ/dV = C_bg + Σ_j Q_j · ξ_eq(1-ξ_eq)/w_j
        저율(0.05C/GITT) OCV 피팅(S1 단계)에 쓰는 기준선. 지연 없음(꼬리 없음).
        """
        V = np.asarray(V_internal, dtype=float)
        # 배경 C_bg (상수 또는 함수) — 항상 V 와 같은 shape 으로
        baseline = (np.asarray(self.background(V), dtype=float) * np.ones_like(V)
                    if callable(self.background)
                    else np.full_like(V, float(self.background)))
        dqdv = baseline
        for tr in self.transitions:
            occ_eq = equilibrium_occupation(V, tr['U'], tr['w'])    # ξ_eq
            # 평형 peak 형상 = 로지스틱의 미분 = ξ_eq(1-ξ_eq)/w  (대칭 종)
            dqdv = dqdv + tr['Q'] * occ_eq * (1.0 - occ_eq) / tr['w']
        return dqdv

    # ----------------------------------------------------------------------
    def dqdv(self,
             V_app: ScalarOrArray,
             T: float,
             I_abs: float,
             Q_cell: float) -> ScalarOrArray:
        """방전 dQ/dV 곡선 (평활·미분가능).  [_v4.tex 식 (1.76) eq:closed; V_n 환산 = 식 (1.45) eq:vapp]

        dQ/dV_app = C_bg + Σ_j Q_j · (ξ_eq,j - ξ_j) / L_V_j
        ξ_j 는 ξ_eq 를 지연 길이 L_V 로 지연(인과·지수필터)시킨 매끈한 점유율.
        indicator/하드컷이 없어 전 구간 미분가능(C1 연속).

        반환: 입력 V_app 와 같은 shape 의 dQ/dV [Q_cell/V].
        """
        # — 입력을 배열로 정규화(스칼라도 허용) —
        V_in = np.asarray(V_app, dtype=float)
        is_scalar = (V_in.ndim == 0)
        V_in = np.atleast_1d(V_in)
        # — 측정전위 → 내부전위: V_n = V_app - σ_d·|I|·R_n  (방전 σ_d=+1) [eq:vapp] —
        V_internal = V_in - (+1) * I_abs * self.polarization_resistance
        # — 지수필터(합성곱)는 "균일 격자" 가 필요하므로 내부 작업 격자를 만든다 —
        v_lo, v_hi = float(np.min(V_internal)), float(np.max(V_internal))
        v_span = max(v_hi - v_lo, 1e-6)
        n_work = max(2048, V_internal.size * 2)        # 충분히 촘촘한 격자
        # 방전(전위 증가)에서 꼬리가 낮은 V 쪽 과거를 기억하므로 아래쪽을 넉넉히 패딩
        V_work = np.linspace(v_lo - 0.15 * v_span, v_hi + 0.05 * v_span, n_work)
        grid_step = V_work[1] - V_work[0]              # ΔV (균일)
        # — 배경 C_bg 로 초기화 (작업 격자 위) —
        dqdv_work = (np.asarray(self.background(V_work), dtype=float) * np.ones_like(V_work)
                     if callable(self.background)
                     else np.full_like(V_work, float(self.background)))

        for tr in self.transitions:
            # 1) 분기중심 U^d (상분리 파라미터가 있으면 분기, 없으면 기본중심 U)
            if ('Omega' in tr) or ('gamma' in tr):
                center = branch_center(T, tr['U'], tr.get('Omega', 0.0),
                                       tr.get('gamma', 0.0), +1, tr.get('h_eta', 1.0))
            else:
                center = tr['U']
            # 2) 평형 점유 ξ_eq (매끈)
            occ_eq = equilibrium_occupation(V_work, center, tr['w'])
            # 3) 지연 길이 L_V (직접 지정 or 동역학 계산)
            lag_len_V = self._resolve_lag_length(tr, T, I_abs, Q_cell)
            # 4) 이 전이의 dQ/dV 기여 = Q_j · dξ_j/dV
            if (not np.isfinite(lag_len_V)) or lag_len_V < 2.0 * grid_step:
                # L_V 가 격자보다 작음(저율 |I|→0 포함) → 지연이 sub-grid → 평형 종 직접
                #   dξ_j/dV → dξ_eq/dV = ξ_eq(1-ξ_eq)/w   (0除/필터 미해상 방지)
                peak_shape = occ_eq * (1.0 - occ_eq) / tr['w']
            else:
                # 지연 점유 ξ_j = ξ_eq 의 인과 지수 저역통과(매끈, = eq:memory 합성곱)
                occ_lagged = _causal_lowpass(np.asarray(occ_eq, dtype=float), grid_step, lag_len_V)
                # 관측 형상 dξ_j/dV = (ξ_eq - ξ_j)/L_V   (매끈, indicator 없음)
                peak_shape = (occ_eq - occ_lagged) / lag_len_V
            dqdv_work = dqdv_work + tr['Q'] * peak_shape

        # — 내부 작업 격자 → 사용자 입력 격자로 매끈하게 보간 —
        dqdv_out = np.interp(V_internal, V_work, dqdv_work)
        return float(dqdv_out[0]) if is_scalar else dqdv_out


# ==============================================================================
# 사용 예시 (이 파일을 직접 실행하면 동작 확인)
# ==============================================================================
if __name__ == "__main__":
    voltage_grid = np.linspace(0.03, 0.34, 1000)        # 측정 전위 격자 [V]
    # 4개 stage 전이 예시 (L_V 직접 지정 = 가장 단순한 사용법)
    graphite_transitions = [
        # 중심 U[V], 폭 w[V], 면적 Q, 지연길이 L_V[V]
        {'U': 0.085, 'w': 0.012, 'Q': 0.35, 'L_V': 0.010},
        {'U': 0.110, 'w': 0.010, 'Q': 0.30, 'L_V': 0.012},
        {'U': 0.140, 'w': 0.016, 'Q': 0.20, 'L_V': 0.020},
        {'U': 0.210, 'w': 0.022, 'Q': 0.15, 'L_V': 0.030},
    ]
    model = GraphiteAnodeDischargeDQDV(graphite_transitions, chi=0.5, Rn=0.01, Cbg=0.05)

    dqdv_curve = model.dqdv(voltage_grid, T=298.15, I_abs=0.02, Q_cell=1.0)
    equilibrium_curve = model.equilibrium(voltage_grid)   # 저율 평형 기준선

    print(f"dQ/dV : min={np.min(dqdv_curve):.3f}, max={np.max(dqdv_curve):.3f}, "
          f"모두 유한={np.all(np.isfinite(dqdv_curve))}")
    # 매끈함 지표(2계 차분 최대 / 동적범위) — 작을수록 매끈
    smoothness = np.max(np.abs(np.diff(dqdv_curve, 2))) / (np.max(dqdv_curve) - np.min(dqdv_curve))
    print(f"매끈함 지표(max|2차차분|/range) = {smoothness:.2e}  (작을수록 매끈)")
